<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="MatomoCamp" tilewidth="32" tileheight="32" tilecount="300" columns="20">
 <image source="WA-Additional_Tiles_MatomoCamp.png" width="640" height="480"/>
</tileset>
